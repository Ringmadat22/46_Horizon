function show() {
  /* Access image by id and change 
  the display property to block*/
  document.getElementById('image')
      .style.display = "block";
  document.getElementById('btnID')
      .style.display = "none";
}